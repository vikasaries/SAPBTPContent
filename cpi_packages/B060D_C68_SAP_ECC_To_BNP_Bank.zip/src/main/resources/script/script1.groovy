import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        def headers = message.getHeaders();
        messageLog.addCustomHeaderProperty("Sender", headers.get("Sender"));
        messageLog.addCustomHeaderProperty("Receiver", headers.get("Receiver"));
        messageLog.addCustomHeaderProperty("MsgId", headers.get("MsgId"));
    }
    return message;
}
