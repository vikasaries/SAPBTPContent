import com.sap.gateway.ip.core.customdev.util.Message
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.xpath.XPathFactory
import org.xml.sax.InputSource
import java.io.StringReader
import org.slf4j.LoggerFactory;

//class XmlParser1{
    
//def log = LoggerFactory.getLogger(XmlParser1.class);
def Message processData(Message message) {
    
    //log.info("Message:"+message);
    def xmlContent = message.getBody(String)

    if (xmlContent == null || xmlContent.trim().isEmpty()) {
        message.setHeader("MsgId", "Data not Avaialbe")
        return message
    }

    try {
        def docBuilderFactory = DocumentBuilderFactory.newInstance()
        docBuilderFactory.setNamespaceAware(true)
        def docBuilder = docBuilderFactory.newDocumentBuilder()
        def document = docBuilder.parse(new InputSource(new StringReader(xmlContent)))

        def xpath = XPathFactory.newInstance().newXPath()
        def msgId = xpath.evaluate("//*[local-name()='GrpHdr']/*[local-name()='MsgId']", document)
        
        message.setHeader("MsgId", msgId)

        /*
        if (msgId == null || msgId.trim().isEmpty()) {
            message.setHeader("MsgId", "Error: MsgId not found in XML")
        } else {
            message.setHeader("MsgId", msgId)
        }
        */
    } catch (Exception e) {
        //message.setHeader("MsgId", "Error: " + (e.getMessage() ?: "Unknown error"))
    }

    return message
}
//}
