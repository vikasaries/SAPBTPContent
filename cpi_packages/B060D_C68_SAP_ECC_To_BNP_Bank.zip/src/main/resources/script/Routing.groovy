import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve file name from properties or headers
    String fileName = message.getProperty("P_FileName");
    def targetDirectory = ""

    // Use switch-case with closures for pattern matching
    switch (fileName.toUpperCase()) {
        case { it.contains("IPHBNP") }:
            targetDirectory = "/AGTRAX/outbound/BNP/PAIN00100109"
            break
        case { it.contains("SDDBNP") }:
            targetDirectory = "/AGTRAX/outbound/BNP/PAIN00800108/SDD"
            break
        case { it.contains("DCOBNP") }:
            targetDirectory = "/AGTRAX/outbound/BNP/PAIN00800102/DCO"
            break
        case { it.contains("RFTBNP") }:
            targetDirectory = "/AGTRAX/outbound/BNP/PAIN00800102/RFT"
            break
            }

    // Set the target directory as a header
     message.setHeader("SFTP_Directory", targetDirectory)
    return message
}
